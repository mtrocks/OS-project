def calculate_metrics(processes, total_time):
    n = len(processes)

    total_TAT = sum(p.tat for p in processes)
    total_WT = sum(p.wt for p in processes)
    total_RT = sum(p.rt for p in processes)
    total_burst = sum(p.burst for p in processes)

    return {
        "total_time": total_time,
        "avg_tat": total_TAT / n,
        "avg_wt": total_WT / n,
        "avg_rt": total_RT / n,
        "throughput": n / total_time,
        "cpu_util": (total_burst / total_time) * 100
    }